---
map: "/maps/Mythic Bastionland/GM/MB Campaign 1 Realm (GM).png"
tags:
  - gm-display
  - map-notes
  - mythic-bastionland
---

# Map Notes — MB Campaign 1 Realm (GM).png

## 1,1

**Forest**

### Myth 1 — The Imp (p61)

Omens revealed so far: 0. Ending a Phase here reveals the next Omen with no Wilderness Roll.

## 1,2

**Forest**

### Barrier

Cannot travel to 2,3 by normal means.

## 1,3

**Forest**

## 1,4

**Glade**

### Barrier

Cannot travel to 2,5 by normal means.

## 1,5

**Valley** · navigable river

## 1,6

**Heath**

### Dwelling

Dwellings — humble homes amid the wilds.

## 1,7

**Heath**

## 1,8

**Heath**

## 1,9

**Peaks**

## 1,10

**Peaks**

### Barrier

Cannot travel to 2,10 by normal means.

## 1,11

**Peaks**

### Myth 6 — The Dwarf (p73)

Omens revealed so far: 0. Ending a Phase here reveals the next Omen with no Wilderness Roll.

## 1,12

**Peaks**

## 2,1

**Forest**

## 2,2

**Forest**

## 2,3

**Glade**

### Dwelling

Dwellings — humble homes amid the wilds.

### Barrier

Cannot travel to 1,2 by normal means.

## 2,4

**Crag**

## 2,5

**Crag** · navigable river

### Barrier

Cannot travel to 1,4 by normal means.

## 2,6

**Heath**

## 2,7

**Heath**

## 2,8

**Heath**

### Barrier

Cannot travel to 2,9 by normal means.

## 2,9

**Peaks**

### Barrier

Cannot travel to 2,8 by normal means.

## 2,10

**Meadow**

### Fortress — Fortress

Held by a Knight or influential Vassal.

### Barrier

Cannot travel to 1,10 by normal means.

## 2,11

**Peaks**

## 2,12

**Peaks**

## 3,1

**Marsh**

## 3,2

**Forest**

## 3,3

**Glade**

## 3,4

**Glade**

## 3,5

**Crag** · navigable river

## 3,6

**Heath**

### Barrier

Cannot travel to 4,5 by normal means.

## 3,7

**Heath**

### Ruin

Ruins — remnants of the past that echo the future. Hint at a random Myth not currently active in the Realm.

## 3,8

**Hills**

## 3,9

**Meadow**

### Curse

Curse — a blight on the land that throws you off course. Travelling in the next Phase counts as travelling blind (p18).

## 3,10

**Meadow**

### Barrier

Cannot travel to 3,11 by normal means.

## 3,11

**Peaks**

### Barrier

Cannot travel to 3,10 by normal means.

## 3,12

**Meadow**

## 4,1

**Peaks**

## 4,2

**Peaks**

### Barrier

Cannot travel to 5,3 by normal means.

## 4,3

**Glade**

## 4,4

**Glade**

## 4,5

**Lake** · navigable river

### Barrier

Cannot travel to 3,6 by normal means.

## 4,6

**Plains**

## 4,7

**Hills**

## 4,8

**Hills**

### Sanctum

Sanctum — sacred home to a Seer. Roll on the Knight table (p26) to find which Seer lives here.

## 4,9

**Meadow**

## 4,10

**Meadow**

### Barrier

Cannot travel to 5,11 by normal means.

## 4,11

**Meadow**

## 4,12

**Glade**

## 5,1

**Peaks**

## 5,2

**Peaks**

### Barrier

Cannot travel to 6,2 by normal means.

## 5,3

**Crag**

### Curse

Curse — a blight on the land that throws you off course. Travelling in the next Phase counts as travelling blind (p18).

### Barrier

Cannot travel to 4,2 by normal means.

## 5,4

**Hills**

## 5,5

**Plains**

### Castle — Seat of Power

Lord Ogan, king of the Realm. Golden hair, cold physique, eclectic dress, erratic tone, formal manner, unstable demeanour; interested in hunting. Desires marriage, motivated by recognition.
Biggest feature: a “wild bridge”. Bailey: sophisticated garrison. Keep: throne at centrepiece, scripture decoration.

## 5,6

**Plains**

## 5,7

**Plains**

## 5,8

**Plains**

### Myth 2 — The Elephant (p163)

Omens revealed so far: 2. Ending a Phase here reveals the next Omen with no Wilderness Roll.

## 5,9

**Hills**

### Barrier

Cannot travel to 5,10 by normal means.

## 5,10

**Glade**

### Barrier

Cannot travel to 5,9 by normal means.

## 5,11

**Glade**

### Barrier

Cannot travel to 4,10 by normal means.

## 5,12

**Glade**

### Ruin

Ruins — remnants of the past that echo the future. Hint at a random Myth not currently active in the Realm.

## 6,1

**Peaks**

## 6,2

**Peaks**

### Barrier

Cannot travel to 5,2 by normal means.

## 6,3

**Hills**

## 6,4

**Hills**

## 6,5

**Plains**

## 6,6

**Hills**

### Barrier

Cannot travel to 6,7 by normal means.

## 6,7

**Plains**

### Barrier

Cannot travel to 6,6 by normal means.

## 6,8

**Plains**

## 6,9

**Hills**

## 6,10

**Heath**

## 6,11

**Heath**

### Barrier

Cannot travel to 7,11 by normal means.

## 6,12

**Heath**

## 7,1

**Valley** · navigable river

## 7,2

**Valley** · navigable river

### Barrier

Cannot travel to 7,3 · 8,2 by normal means.

## 7,3

**Peaks**

### Barrier

Cannot travel to 7,2 by normal means.

## 7,4

**Valley** · navigable river

## 7,5

**Hills**

### Barrier

Cannot travel to 8,5 by normal means.

## 7,6

**Hills**

### Monument

Monument — a site of inspiration. Travellers may spend a Phase to restore SPI here as if consuming a Sacrament.

## 7,7

**Plains**

## 7,8

**Plains**

## 7,9

**Plains**

### Hazard

Hazard — nature fights your every step. Devise a solution, push through (lose d6 VIG), or go back the way you came.

## 7,10

**Marsh**

## 7,11

**Heath**

### Barrier

Cannot travel to 6,11 by normal means.

## 7,12

**Heath**

### Sanctum

Sanctum — sacred home to a Seer. Roll on the Knight table (p26) to find which Seer lives here.

### Barrier

Cannot travel to 8,11 by normal means.

## 8,1

**Peaks**

## 8,2

**Peaks**

### Barrier

Cannot travel to 7,2 by normal means.

## 8,3

**Valley** · navigable river

## 8,4

**Forest**

## 8,5

**Valley** · navigable river

### Barrier

Cannot travel to 7,5 by normal means.

## 8,6

**Valley** · navigable river

### Barrier

Cannot travel to 9,6 by normal means.

## 8,7

**Plains**

## 8,8

**Plains**

### Town — Town

Walled town on the edge of the marshes.

## 8,9

**Marsh**

### Sanctum

Sanctum — sacred home to a Seer. Roll on the Knight table (p26) to find which Seer lives here.

## 8,10

**Marsh**

### Barrier

Cannot travel to 9,10 by normal means.

## 8,11

**Marsh**

### Barrier

Cannot travel to 7,12 by normal means.

## 8,12

**Bog**

### Hazard

Hazard — nature fights your every step. Devise a solution, push through (lose d6 VIG), or go back the way you came.

## 9,1

**Peaks**

## 9,2

**Peaks**

### Barrier

Cannot travel to 10,2 by normal means.

## 9,3

**Forest**

### Curse

Curse — a blight on the land that throws you off course. Travelling in the next Phase counts as travelling blind (p18).

## 9,4

**Forest**

### Barrier

Cannot travel to 10,5 by normal means.

## 9,5

**Valley** · navigable river

## 9,6

**Plains**

### Barrier

Cannot travel to 8,6 by normal means.

## 9,7

**Valley** · navigable river

## 9,8

**Bog**

## 9,9

**Bog**

## 9,10

**Bog**

### Barrier

Cannot travel to 8,10 by normal means.

## 9,11

**Bog**

## 9,12

**Bog**

## 10,1

**Crag**

### Ruin

Ruins — remnants of the past that echo the future. Hint at a random Myth not currently active in the Realm.

### Barrier

Cannot travel to 11,1 by normal means.

## 10,2

**Lake**

### Barrier

Cannot travel to 9,2 by normal means.

## 10,3

**Crag**

### Tower — Tower

Tower overlooking the lakes.

## 10,4

**Valley** · navigable river

## 10,5

**Valley** · navigable river

### Barrier

Cannot travel to 9,4 by normal means.

## 10,6

**Plains**

## 10,7

**Valley** · navigable river

## 10,8

**Valley** · navigable river

## 10,9

**Bog**

## 10,10

**Marsh**

### Monument

Monument — a site of inspiration. Travellers may spend a Phase to restore SPI here as if consuming a Sacrament.

### Barrier

Cannot travel to 11,9 by normal means.

## 10,11

**Bog**

### Myth 5 — The Sprite (p145)

Omens revealed so far: 0. Ending a Phase here reveals the next Omen with no Wilderness Roll.

## 10,12

**Meadow**

## 11,1

**Peaks**

### Barrier

Cannot travel to 10,1 by normal means.

## 11,2

**Lake** · navigable river

## 11,3

**Lake** · navigable river

### Myth 3 — The Sea (p67)

Omens revealed so far: 0. Ending a Phase here reveals the next Omen with no Wilderness Roll.

## 11,4

**Plains**

### Dwelling

Dwellings — humble homes amid the wilds.

## 11,5

**Plains**

## 11,6

**Plains**

### Monument

Monument — a site of inspiration. Travellers may spend a Phase to restore SPI here as if consuming a Sacrament.

### Barrier

Cannot travel to 11,7 by normal means.

## 11,7

**Peaks**

### Barrier

Cannot travel to 11,6 by normal means.

## 11,8

**Valley** · navigable river

### Hazard

Hazard — nature fights your every step. Devise a solution, push through (lose d6 VIG), or go back the way you came.

## 11,9

**Crag**

### Barrier

Cannot travel to 10,10 by normal means.

## 11,10

**Crag**

## 11,11

**Meadow**

### Barrier

Cannot travel to 12,11 by normal means.

## 11,12

**Meadow**

## 12,1

**Peaks**

## 12,2

**Peaks**

## 12,3

**Peaks**

## 12,4

**Plains**

## 12,5

**Plains**

## 12,6

**Peaks**

## 12,7

**Peaks**

## 12,8

**Peaks**

## 12,9

**Crag** · navigable river

### Myth 4 — The Lizard (p95)

Omens revealed so far: 2. Ending a Phase here reveals the next Omen with no Wilderness Roll.

## 12,10

**Crag**

## 12,11

**Crag**

### Barrier

Cannot travel to 11,11 by normal means.

## 12,12

**Crag**
