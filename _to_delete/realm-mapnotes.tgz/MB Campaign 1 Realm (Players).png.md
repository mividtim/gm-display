---
map: "/maps/Mythic Bastionland/Players/MB Campaign 1 Realm (Players).png"
tags:
  - gm-display
  - map-notes
  - mythic-bastionland
---

# Map Notes — MB Campaign 1 Realm (Players).png

## 1,1

**Forest**

## 1,2

**Forest**

## 1,3

**Forest**

## 1,4

**Glade**

## 1,5

**Valley**

## 1,6

**Heath**

## 1,7

**Heath**

## 1,8

**Heath**

## 1,9

**Peaks**

## 1,10

**Peaks**

## 1,11

**Peaks**

## 1,12

**Peaks**

## 2,1

**Forest**

## 2,2

**Forest**

## 2,3

**Glade**

## 2,4

**Crag**

## 2,5

**Crag**

## 2,6

**Heath**

## 2,7

**Heath**

## 2,8

**Heath**

## 2,9

**Peaks**

## 2,10

**Meadow**

## 2,11

**Peaks**

## 2,12

**Peaks**

## 3,1

**Marsh**

## 3,2

**Forest**

## 3,3

**Glade**

## 3,4

**Glade**

## 3,5

**Crag**

## 3,6

**Heath**

## 3,7

**Heath**

## 3,8

**Hills**

## 3,9

**Meadow**

## 3,10

**Meadow**

## 3,11

**Peaks**

## 3,12

**Meadow**

## 4,1

**Peaks**

## 4,2

**Peaks**

## 4,3

**Glade**

## 4,4

**Glade**

## 4,5

**Lake**

## 4,6

**Plains**

## 4,7

**Hills**

## 4,8

**Hills**

## 4,9

**Meadow**

## 4,10

**Meadow**

## 4,11

**Meadow**

## 4,12

**Glade**

## 5,1

**Peaks**

## 5,2

**Peaks**

## 5,3

**Crag**

## 5,4

**Hills**

## 5,5

**Plains**

## 5,6

**Plains**

## 5,7

**Plains**

## 5,8

**Plains**

## 5,9

**Hills**

## 5,10

**Glade**

## 5,11

**Glade**

## 5,12

**Glade**

## 6,1

**Peaks**

## 6,2

**Peaks**

## 6,3

**Hills**

## 6,4

**Hills**

## 6,5

**Plains**

## 6,6

**Hills**

## 6,7

**Plains**

## 6,8

**Plains**

## 6,9

**Hills**

## 6,10

**Heath**

## 6,11

**Heath**

## 6,12

**Heath**

## 7,1

**Valley**

## 7,2

**Valley**

## 7,3

**Peaks**

## 7,4

**Valley**

## 7,5

**Hills**

## 7,6

**Hills**

## 7,7

**Plains**

## 7,8

**Plains**

## 7,9

**Plains**

## 7,10

**Marsh**

## 7,11

**Heath**

## 7,12

**Heath**

## 8,1

**Peaks**

## 8,2

**Peaks**

## 8,3

**Valley**

## 8,4

**Forest**

## 8,5

**Valley**

## 8,6

**Valley**

## 8,7

**Plains**

## 8,8

**Plains**

## 8,9

**Marsh**

## 8,10

**Marsh**

## 8,11

**Marsh**

## 8,12

**Bog**

## 9,1

**Peaks**

## 9,2

**Peaks**

## 9,3

**Forest**

## 9,4

**Forest**

## 9,5

**Valley**

## 9,6

**Plains**

## 9,7

**Valley**

## 9,8

**Bog**

## 9,9

**Bog**

## 9,10

**Bog**

## 9,11

**Bog**

## 9,12

**Bog**

## 10,1

**Crag**

## 10,2

**Lake**

## 10,3

**Crag**

## 10,4

**Valley**

## 10,5

**Valley**

## 10,6

**Plains**

## 10,7

**Valley**

## 10,8

**Valley**

## 10,9

**Bog**

## 10,10

**Marsh**

## 10,11

**Bog**

## 10,12

**Meadow**

## 11,1

**Peaks**

## 11,2

**Lake**

## 11,3

**Lake**

## 11,4

**Plains**

## 11,5

**Plains**

## 11,6

**Plains**

## 11,7

**Peaks**

## 11,8

**Valley**

## 11,9

**Crag**

## 11,10

**Crag**

## 11,11

**Meadow**

## 11,12

**Meadow**

## 12,1

**Peaks**

## 12,2

**Peaks**

## 12,3

**Peaks**

## 12,4

**Plains**

## 12,5

**Plains**

## 12,6

**Peaks**

## 12,7

**Peaks**

## 12,8

**Peaks**

## 12,9

**Crag**

## 12,10

**Crag**

## 12,11

**Crag**

## 12,12

**Crag**
